module org.example.cangkugui {
    // 依赖 JavaFX 模块
    requires javafx.controls;
    requires javafx.fxml;

    // 导出主应用包
    exports org.example.cangkugui;

    // 开放给 JavaFX 反射访问（用于 FXML 加载）
    opens org.example.cangkugui to javafx.fxml;
}