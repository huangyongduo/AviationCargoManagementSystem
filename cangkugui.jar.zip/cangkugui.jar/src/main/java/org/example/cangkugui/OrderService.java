package org.example.cangkugui;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javafx.application.Platform;

public class OrderService {
    private final Stage primaryStage;
    private final UserManager userManager;
    private Label statusLabel;
    private CargoManagementPanel cargoManagementPanel;

    public OrderService(Stage primaryStage, UserManager userManager, Label statusLabel, CargoManagementPanel cargoManagementPanel) {
        this.primaryStage = primaryStage;
        this.userManager = userManager;
        this.statusLabel = statusLabel;
        this.cargoManagementPanel = cargoManagementPanel;
    }

    // 显示下订单页面
    public void showPlaceOrderPage(String username) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("下订单");
        dialog.setHeaderText("请输入订单信息");

        // 设置对话框按钮
        ButtonType placeOrderButtonType = new ButtonType("下单", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(placeOrderButtonType, ButtonType.CANCEL);

        // 创建输入表单
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField orderIdField = new TextField();
        orderIdField.setPromptText("订单 ID");
        ListView<CargoManagementPanel.Cargo> cargoListView = new ListView<>();
        Button addCargoButton = new Button("添加货物");
        addCargoButton.setOnAction(e -> showAddCargoDialog(cargoListView, username));

        TextField senderField = new TextField();
        senderField.setPromptText("发件人");
        TextField recipientField = new TextField();
        recipientField.setPromptText("收件人");

        grid.add(new Label("订单 ID:"), 0, 0);
        grid.add(orderIdField, 1, 0);
        grid.add(new Label("发件人:"), 0, 1);
        grid.add(senderField, 1, 1);
        grid.add(new Label("收件人:"), 0, 2);
        grid.add(recipientField, 1, 2);
        grid.add(new Label("货物列表:"), 0, 3);
        grid.add(cargoListView, 1, 3);
        grid.add(addCargoButton, 2, 3);

        dialog.getDialogPane().setContent(grid);

        // 禁用下单按钮直到输入有效
        Button placeOrderButton = (Button) dialog.getDialogPane().lookupButton(placeOrderButtonType);
        placeOrderButton.setDisable(true);

        // 监听输入字段变化
        orderIdField.textProperty().addListener((observable, oldValue, newValue) -> {
            placeOrderButton.setDisable(newValue.trim().isEmpty() || cargoListView.getItems().isEmpty() || senderField.getText().trim().isEmpty() || recipientField.getText().trim().isEmpty());
        });

        cargoListView.getItems().addListener((javafx.collections.ListChangeListener.Change<? extends CargoManagementPanel.Cargo> c) -> {
            placeOrderButton.setDisable(orderIdField.getText().trim().isEmpty() || cargoListView.getItems().isEmpty() || senderField.getText().trim().isEmpty() || recipientField.getText().trim().isEmpty());
        });

        senderField.textProperty().addListener((observable, oldValue, newValue) -> {
            placeOrderButton.setDisable(newValue.trim().isEmpty() || orderIdField.getText().trim().isEmpty() || cargoListView.getItems().isEmpty() || recipientField.getText().trim().isEmpty());
        });

        recipientField.textProperty().addListener((observable, oldValue, newValue) -> {
            placeOrderButton.setDisable(newValue.trim().isEmpty() || orderIdField.getText().trim().isEmpty() || cargoListView.getItems().isEmpty() || senderField.getText().trim().isEmpty());
        });

        // 处理对话框结果
        dialog.setResultConverter(dialogButton -> {
            return dialogButton;
        });

        // 显示对话框并处理结果
        Optional<ButtonType> result = dialog.showAndWait();
        result.ifPresent(buttonType -> {
            if (buttonType == placeOrderButtonType) {
                String orderId = orderIdField.getText();
                String sender = senderField.getText();
                String recipient = recipientField.getText();
                Order order = new Order(orderId, username, sender, recipient);
                for (CargoManagementPanel.Cargo cargo : cargoListView.getItems()) {
                    order.addCargo(cargo);
                }
                // 计算运费
                double freight = calculateFreight(order);
                order.setFreight(freight);
                // 保存订单
                saveOrder(order);
                statusLabel.setText("订单 " + orderId + " 已创建，运费: " + freight);
                statusLabel.setTextFill(Color.GREEN);
            }
        });
    }

    // 显示修改订单页面（恢复的原有方法）
    public void showModifyOrderPage(String username) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("修改订单");
        dialog.setHeaderText("请选择要修改的订单");

        // 设置对话框按钮
        ButtonType modifyButtonType = new ButtonType("修改", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(modifyButtonType, ButtonType.CANCEL);

        // 创建订单选择列表
        ListView<String> orderListView = new ListView<>();
        loadOrderIdsForUser(username, orderListView);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        grid.add(new Label("选择订单:"), 0, 0);
        grid.add(orderListView, 0, 1);

        dialog.getDialogPane().setContent(grid);

        // 禁用修改按钮直到选择订单
        Button modifyButton = (Button) dialog.getDialogPane().lookupButton(modifyButtonType);
        modifyButton.setDisable(true);

        orderListView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            modifyButton.setDisable(newValue == null);
        });

        // 处理对话框结果
        dialog.setResultConverter(dialogButton -> {
            return dialogButton;
        });

        // 显示对话框并处理结果
        Optional<ButtonType> result = dialog.showAndWait();
        result.ifPresent(buttonType -> {
            if (buttonType == modifyButtonType) {
                String selectedOrderId = orderListView.getSelectionModel().getSelectedItem();
                if (selectedOrderId != null) {
                    showOrderModifyForm(username, selectedOrderId);
                }
            }
        });
    }

    // 加载用户的订单ID到列表
    private void loadOrderIdsForUser(String username, ListView<String> orderListView) {
        try (BufferedReader reader = new BufferedReader(new FileReader("src/orders.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2 && parts[1].equals(username)) {
                    String orderId = parts[0];
                    if (!orderListView.getItems().contains(orderId)) {
                        orderListView.getItems().add(orderId);
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("读取订单数据失败: " + e.getMessage());
        }
    }

    // 显示订单修改表单
    private void showOrderModifyForm(String username, String orderId) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("修改订单");
        dialog.setHeaderText("修改订单信息");

        // 设置对话框按钮
        ButtonType saveButtonType = new ButtonType("保存", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        // 创建输入表单
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField orderIdField = new TextField(orderId);
        orderIdField.setEditable(false);

        // 加载订单信息
        Order order = loadOrderById(orderId);
        if (order == null) {
            javafx.application.Platform.runLater(() -> {
                System.out.println("订单已完成，无法修改");
                statusLabel.setText("订单不存在或无法加载");
                statusLabel.setTextFill(Color.RED);
            });
            return;
        }

        TextField senderField = new TextField(order.getSender());
        TextField recipientField = new TextField(order.getRecipient());
        ListView<CargoManagementPanel.Cargo> cargoListView = new ListView<>();
        cargoListView.getItems().addAll(order.getCargoList());

        Button addCargoButton = new Button("添加货物");
        addCargoButton.setOnAction(e -> showAddCargoDialog(cargoListView, username));

        Button removeCargoButton = new Button("删除选中货物");
        removeCargoButton.setOnAction(e -> {
            CargoManagementPanel.Cargo selectedCargo = cargoListView.getSelectionModel().getSelectedItem();
            if (selectedCargo != null) {
                cargoListView.getItems().remove(selectedCargo);
            }
        });

        grid.add(new Label("订单 ID:"), 0, 0);
        grid.add(orderIdField, 1, 0);
        grid.add(new Label("发件人:"), 0, 1);
        grid.add(senderField, 1, 1);
        grid.add(new Label("收件人:"), 0, 2);
        grid.add(recipientField, 1, 2);
        grid.add(new Label("货物列表:"), 0, 3);
        grid.add(cargoListView, 1, 3);
        grid.add(addCargoButton, 2, 3);
        grid.add(removeCargoButton, 2, 4);

        dialog.getDialogPane().setContent(grid);

        // 处理对话框结果
        dialog.setResultConverter(dialogButton -> {
            return dialogButton;
        });

        // 显示对话框并处理结果
        Optional<ButtonType> result = dialog.showAndWait();
        result.ifPresent(buttonType -> {
            if (buttonType == saveButtonType) {
                String sender = senderField.getText();
                String recipient = recipientField.getText();

                // 更新订单信息
                order.setSender(sender);
                order.setRecipient(recipient);

                // 清空原有货物并添加新的货物列表
                order.getCargoList().clear();
                for (CargoManagementPanel.Cargo cargo : cargoListView.getItems()) {
                    order.addCargo(cargo);
                }

                // 重新计算运费
                double freight = calculateFreight(order);
                order.setFreight(freight);

                // 保存修改后的订单
                updateOrder(order);

                statusLabel.setText("订单 " + orderId + " 已修改，新运费: " + freight);
                statusLabel.setTextFill(Color.GREEN);
            }
        });
    }

    // 加载订单信息
    private Order loadOrderById(String orderId) {
        try (BufferedReader reader = new BufferedReader(new FileReader("src/orders.txt"))) {
            String line;
            Order order = null;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 12 && parts[0].equals(orderId)) {
                    if (order == null) {
                        String username = parts[1];
                        double freight = Double.parseDouble(parts[2]);
                        boolean isPaid = Boolean.parseBoolean(parts[3]);
                        String sender = parts[10];
                        String recipient = parts[11];

                        order = new Order(orderId, username, sender, recipient);
                        order.setFreight(freight);
                        order.setPaid(isPaid);
                    }

                    // 添加货物
                    String cargoId = parts[4];
                    String name = parts[5];
                    double weight = Double.parseDouble(parts[6]);
                    String destination = parts[7];
                    String flightNumber = parts[8];
                    String departureDate = parts[9];

                    CargoManagementPanel.Cargo cargo = new CargoManagementPanel.Cargo(
                            order.getUser(), cargoId, name, weight, destination, flightNumber, departureDate, "待运输");

                    order.addCargo(cargo);
                }
            }
            return order;
        } catch (IOException e) {
            System.err.println("读取订单数据失败: " + e.getMessage());
            return null;
        }
    }

    // 更新订单信息
    private void updateOrder(Order order) {
        List<String> lines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("src/orders.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2 && parts[0].equals(order.getOrderId()) && parts[1].equals(order.getUser())) {
                    // 跳过原有订单行
                    continue;
                }
                lines.add(line);
            }
        } catch (IOException e) {
            System.err.println("读取订单数据失败: " + e.getMessage());
        }

        // 添加更新后的订单行
        for (CargoManagementPanel.Cargo cargo : order.getCargoList()) {
            lines.add(String.format("%s,%s,%.2f,%b,%s,%s,%.2f,%s,%s,%s,%s,%s\n",
                    order.getOrderId(),
                    order.getUser(),
                    order.getFreight(),
                    order.isPaid(),
                    cargo.getCargoId(),
                    cargo.getName(),
                    cargo.getWeight(),
                    cargo.getDestination(),
                    cargo.getFlightNumber(),
                    cargo.getDepartureDate(),
                    order.getSender(),
                    order.getRecipient()
            ));
        }

        // 写入文件
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("src/orders.txt"))) {
            for (String line : lines) {
                writer.write(line);
            }
        } catch (IOException e) {
            System.err.println("保存订单数据失败: " + e.getMessage());
        }
    }

    // 显示添加货物对话框
    private void showAddCargoDialog(ListView<CargoManagementPanel.Cargo> cargoListView, String username) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("添加货物");
        dialog.setHeaderText("请输入货物信息");

        // 设置对话框按钮
        ButtonType addCargoButtonType = new ButtonType("添加", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(addCargoButtonType, ButtonType.CANCEL);

        // 创建输入表单
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField cargoIdField = new TextField();
        cargoIdField.setPromptText("货物 ID");
        TextField nameField = new TextField();
        nameField.setPromptText("货物名称");
        TextField weightField = new TextField();
        weightField.setPromptText("货物重量(kg)");
        TextField destinationField = new TextField();
        destinationField.setPromptText("目的地");
        TextField flightNumberField = new TextField();
        flightNumberField.setPromptText("航班号");
        TextField departureDateField = new TextField();
        departureDateField.setPromptText("预计起飞时间");
        ComboBox<String> statusComboBox = new ComboBox<>();
        statusComboBox.getItems().addAll("待运输", "运输中", "已到达", "已签收");
        statusComboBox.setValue("待运输");

        grid.add(new Label("货物 ID:"), 0, 0);
        grid.add(cargoIdField, 1, 0);
        grid.add(new Label("货物名称:"), 0, 1);
        grid.add(nameField, 1, 1);
        grid.add(new Label("货物重量(kg):"), 0, 2);
        grid.add(weightField, 1, 2);
        grid.add(new Label("目的地:"), 0, 3);
        grid.add(destinationField, 1, 3);
        grid.add(new Label("航班号:"), 0, 4);
        grid.add(flightNumberField, 1, 4);
        grid.add(new Label("预计起飞时间:"), 0, 5);
        grid.add(departureDateField, 1, 5);
        grid.add(new Label("状态:"), 0, 6);
        grid.add(statusComboBox, 1, 6);

        dialog.getDialogPane().setContent(grid);

        // 禁用添加按钮直到输入有效
        Button addCargoButton = (Button) dialog.getDialogPane().lookupButton(addCargoButtonType);
        addCargoButton.setDisable(true);

        // 监听输入字段变化
        cargoIdField.textProperty().addListener((observable, oldValue, newValue) -> {
            addCargoButton.setDisable(newValue.trim().isEmpty() || nameField.getText().trim().isEmpty() ||
                    weightField.getText().trim().isEmpty() || destinationField.getText().trim().isEmpty() ||
                    flightNumberField.getText().trim().isEmpty() || departureDateField.getText().trim().isEmpty());
        });

        nameField.textProperty().addListener((observable, oldValue, newValue) -> {
            addCargoButton.setDisable(newValue.trim().isEmpty() || cargoIdField.getText().trim().isEmpty() ||
                    weightField.getText().trim().isEmpty() || destinationField.getText().trim().isEmpty() ||
                    flightNumberField.getText().trim().isEmpty() || departureDateField.getText().trim().isEmpty());
        });

        weightField.textProperty().addListener((observable, oldValue, newValue) -> {
            try {
                double weight = Double.parseDouble(newValue);
                addCargoButton.setDisable(false);
            } catch (NumberFormatException e) {
                addCargoButton.setDisable(true);
            }
        });

        destinationField.textProperty().addListener((observable, oldValue, newValue) -> {
            addCargoButton.setDisable(newValue.trim().isEmpty() || cargoIdField.getText().trim().isEmpty() ||
                    weightField.getText().trim().isEmpty() || nameField.getText().trim().isEmpty() ||
                    flightNumberField.getText().trim().isEmpty() || departureDateField.getText().trim().isEmpty());
        });

        flightNumberField.textProperty().addListener((observable, oldValue, newValue) -> {
            addCargoButton.setDisable(newValue.trim().isEmpty() || cargoIdField.getText().trim().isEmpty() ||
                    weightField.getText().trim().isEmpty() || nameField.getText().trim().isEmpty() ||
                    destinationField.getText().trim().isEmpty() || departureDateField.getText().trim().isEmpty());
        });

        departureDateField.textProperty().addListener((observable, oldValue, newValue) -> {
            addCargoButton.setDisable(newValue.trim().isEmpty() || cargoIdField.getText().trim().isEmpty() ||
                    weightField.getText().trim().isEmpty() || nameField.getText().trim().isEmpty() ||
                    destinationField.getText().trim().isEmpty() || flightNumberField.getText().trim().isEmpty());
        });

        // 处理对话框结果
        dialog.setResultConverter(dialogButton -> {
            return dialogButton;
        });

        // 显示对话框并处理结果
        Optional<ButtonType> result = dialog.showAndWait();
        result.ifPresent(buttonType -> {
            if (buttonType == addCargoButtonType) {
                String cargoId = cargoIdField.getText();
                String name = nameField.getText();
                double weight = Double.parseDouble(weightField.getText());
                String destination = destinationField.getText();
                String flightNumber = flightNumberField.getText();
                String departureDate = departureDateField.getText();
                String status = statusComboBox.getValue();
                CargoManagementPanel.Cargo cargo = new CargoManagementPanel.Cargo(username, cargoId, name, weight, destination, flightNumber, departureDate, status);
                cargoListView.getItems().add(cargo);
            }
        });
    }

    // 计算运费
    private double calculateFreight(Order order) {
        // 简单示例：每公斤 10 元
        double totalWeight = 0;
        for (CargoManagementPanel.Cargo cargo : order.getCargoList()) {
            totalWeight += cargo.getWeight();
        }
        return totalWeight * 10;
    }

    // 保存订单
    private void saveOrder(Order order) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("src/orders.txt", true))) {
            for (CargoManagementPanel.Cargo cargo : order.getCargoList()) {
                writer.write(String.format("%s,%s,%.2f,%b,%s,%s,%.2f,%s,%s,%s,%s,%s\n",
                        order.getOrderId(),
                        order.getUser(),
                        order.getFreight(),
                        order.isPaid(),
                        cargo.getCargoId(),
                        cargo.getName(),
                        cargo.getWeight(),
                        cargo.getDestination(),
                        cargo.getFlightNumber(),
                        cargo.getDepartureDate(),
                        order.getSender(),
                        order.getRecipient()
                ));
            }
        } catch (IOException e) {
            System.err.println("保存订单数据失败: " + e.getMessage());
        }
    }

    // 处理支付完成
    public void handlePaymentCompleted(Order order) {
        order.setPaid(true);
        // 将订单信息添加到仓库管理中
        for (CargoManagementPanel.Cargo cargo : order.getCargoList()) {
            cargoManagementPanel.getCargoData().add(cargo);
        }
        cargoManagementPanel.saveData();

        // 从 orders.txt 文件中移除已支付的订单信息
        removeOrderFromFile(order.getOrderId());

        statusLabel.setText("订单 " + order.getOrderId() + " 支付完成，已添加到仓库管理");
        statusLabel.setTextFill(Color.GREEN);
    }

    // 从 orders.txt 文件中移除指定订单信息
    private void removeOrderFromFile(String orderId) {
        List<String> lines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("src/orders.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (!parts[0].equals(orderId)) {
                    lines.add(line);
                }
            }
        } catch (IOException e) {
            System.err.println("读取订单数据失败: " + e.getMessage());
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("src/orders.txt"))) {
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("保存订单数据失败: " + e.getMessage());
        }
    }
}