package org.example.cangkugui;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class CargoManagementPanel {
    private final String currentUser;
    private Stage primaryStage;
    private TableView<Cargo> cargoTable;
    private ObservableList<Cargo> cargoData = FXCollections.observableArrayList();
    private Label statusLabel;
    private CargoManagementListener listener;
    private static final String CARGO_DATE_FILE = "src/cargoData.txt";
    private static final String ORDERS_FILE = "src/orders.txt";

    // 货物类定义
    public static class Cargo {
        private final String username;
        private final String cargoId;
        private final String name;
        private final double weight;
        private final String destination;
        private final String flightNumber;
        private final String departureDate;
        private final String status;

        public Cargo(String username, String cargoId, String name, double weight,
                     String destination, String flightNumber, String departureDate, String status) {
            this.username = username;
            this.cargoId = cargoId;
            this.name = name;
            this.weight = weight;
            this.destination = destination;
            this.flightNumber = flightNumber;
            this.departureDate = departureDate;
            this.status = status;
        }

        public String getUsername() {
            return username;
        }

        public String getCargoId() {
            return cargoId;
        }

        public String getName() {
            return name;
        }

        public double getWeight() {
            return weight;
        }

        public String getDestination() {
            return destination;
        }

        public String getFlightNumber() {
            return flightNumber;
        }

        public String getDepartureDate() {
            return departureDate;
        }

        public String getStatus() {
            return status;
        }
    }

    // 回调接口，用于与主应用交互
    public interface CargoManagementListener {
        void onBackToMainMenu();
        void onAddCargo();
        void onEditCargo(Cargo cargo);
        void onDeleteCargo(Cargo cargo);
        void onViewDetails(Cargo cargo);
    }

    public ObservableList<Cargo> getCargoData() {
        return cargoData;
    }

    public void saveData() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CARGO_DATE_FILE))) {
            for (Cargo cargo : cargoData) {
                writer.write(String.format("%s,%s,%s,%.2f,%s,%s,%s,%s\n",
                        cargo.getUsername(),
                        cargo.getCargoId(),
                        cargo.getName(),
                        cargo.getWeight(),
                        cargo.getDestination(),
                        cargo.getFlightNumber(),
                        cargo.getDepartureDate(),
                        cargo.getStatus()
                ));
            }
        } catch (IOException e) {
            System.err.println("保存货物数据失败: " + e.getMessage());
        }
    }

    public CargoManagementPanel(Stage primaryStage, CargoManagementListener listener, String currentUser) throws IOException {
        this.primaryStage = primaryStage;
        this.listener = listener;
        this.currentUser = currentUser;
        loadData();
    }

    public void show() {
        BorderPane root = createMainLayout();
        Scene scene = new Scene(root, 1200, 800);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private BorderPane createMainLayout() {
        BorderPane mainLayout = new BorderPane();
        mainLayout.setPadding(new Insets(10));

        // 顶部标题
        mainLayout.setTop(createHeader());

        // 中间内容区域
        mainLayout.setCenter(createContentArea());

        // 底部状态栏
        mainLayout.setBottom(createStatusBar());

        return mainLayout;
    }

    private HBox createHeader() {
        HBox headerBox = new HBox(20);
        headerBox.setPadding(new Insets(15));
        headerBox.setAlignment(Pos.CENTER_LEFT);
        headerBox.setStyle("-fx-background-color: #336699;");

        Text title = new Text("航空货物管理系统");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        title.setFill(Color.WHITE);

        Button backButton = new Button("返回主菜单");
        backButton.setStyle("-fx-background-color: #607D8B; -fx-text-fill: white;");
        backButton.setOnAction(e -> listener.onBackToMainMenu());

        headerBox.getChildren().addAll(title, new HBox(new Label("   ")), backButton);
        HBox.setHgrow(title, Priority.ALWAYS);

        return headerBox;
    }

    private VBox createContentArea() {
        VBox contentArea = new VBox(20);
        contentArea.setPadding(new Insets(10));

        // 搜索和筛选区域
        contentArea.getChildren().add(createSearchArea());

        // 表格区域
        contentArea.getChildren().add(createTableView());

        // 按钮区域
        contentArea.getChildren().add(createButtonArea());

        return contentArea;
    }

    private HBox createSearchArea() {
        HBox searchArea = new HBox(15);
        searchArea.setPadding(new Insets(10));
        searchArea.setAlignment(Pos.CENTER_LEFT);
        searchArea.setStyle("-fx-background-color: #e6e6e6;");

        Label searchLabel = new Label("搜索:");
        TextField searchField = new TextField();
        searchField.setPromptText("输入货物ID、名称、目的地、发件人或收件人");
        searchField.setPrefWidth(300);

        Label statusLabel = new Label("状态:");
        ComboBox<String> statusFilter = new ComboBox<>();
        statusFilter.getItems().addAll("全部", "待运输", "运输中", "已到达", "已签收");
        statusFilter.setValue("全部");

        Button searchButton = new Button("搜索");
        searchButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        searchButton.setOnAction(e -> handleSearch(searchField.getText(), statusFilter.getValue()));

        Button resetButton = new Button("重置");
        resetButton.setOnAction(e -> {
            searchField.clear();
            statusFilter.setValue("全部");
            handleSearch("", "全部");
        });

        searchArea.getChildren().addAll(
                searchLabel, searchField,
                new HBox(new Label("    ")),
                statusLabel, statusFilter,
                new HBox(new Label("    ")),
                searchButton, resetButton
        );

        return searchArea;
    }

    private TableView<Cargo> createTableView() {
        cargoTable = new TableView<>();
        cargoTable.setItems(cargoData);
        cargoTable.setPrefHeight(500);

        // 用户列
        TableColumn<Cargo, String> userCol = new TableColumn<>("用户名称");
        userCol.setCellValueFactory(new PropertyValueFactory<>("username"));
        userCol.setPrefWidth(150);

        // 货物ID列
        TableColumn<Cargo, String> cargoIdCol = new TableColumn<>("货物ID");
        cargoIdCol.setCellValueFactory(new PropertyValueFactory<>("cargoId"));
        cargoIdCol.setPrefWidth(120);

        // 货物名称列
        TableColumn<Cargo, String> nameCol = new TableColumn<>("货物名称");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        nameCol.setPrefWidth(180);

        // 重量列
        TableColumn<Cargo, Double> weightCol = new TableColumn<>("重量(kg)");
        weightCol.setCellValueFactory(new PropertyValueFactory<>("weight"));
        weightCol.setPrefWidth(100);

        // 目的地列
        TableColumn<Cargo, String> destinationCol = new TableColumn<>("目的地");
        destinationCol.setCellValueFactory(new PropertyValueFactory<>("destination"));
        destinationCol.setPrefWidth(150);

        // 航班号列
        TableColumn<Cargo, String> flightCol = new TableColumn<>("航班号");
        flightCol.setCellValueFactory(new PropertyValueFactory<>("flightNumber"));
        flightCol.setPrefWidth(120);

        // 预计起飞时间列
        TableColumn<Cargo, String> departureCol = new TableColumn<>("预计起飞时间");
        departureCol.setCellValueFactory(new PropertyValueFactory<>("departureDate"));
        departureCol.setPrefWidth(150);

        // 状态列
        TableColumn<Cargo, String> statusCol = new TableColumn<>("状态");
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
        statusCol.setPrefWidth(100);

        // 操作列
        TableColumn<Cargo, Void> actionCol = new TableColumn<>("操作");
        actionCol.setPrefWidth(180);
        actionCol.setCellFactory(param -> new TableCell<>() {
            private final Button viewButton = new Button("查看");
            private final Button editButton = new Button("修改");
            private final HBox buttonBox = new HBox(5);

            {
                viewButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white;");
                editButton.setStyle("-fx-background-color: #FFC107; -fx-text-fill: black;");

                viewButton.setOnAction(e -> {
                    Cargo cargo = getTableView().getItems().get(getIndex());
                    showCargoDetails(cargo);
                });

                editButton.setOnAction(e -> {
                    Cargo cargo = getTableView().getItems().get(getIndex());
                    editCargoDetails(cargo);
                });

                buttonBox.getChildren().addAll(viewButton, editButton);
                buttonBox.setAlignment(Pos.CENTER);
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(buttonBox);
                }
            }
        });

        cargoTable.getColumns().addAll(userCol, cargoIdCol, nameCol, weightCol, destinationCol,
                flightCol, departureCol, statusCol, actionCol);

        return cargoTable;
    }

    private HBox createButtonArea() {
        HBox buttonArea = new HBox(15);
        buttonArea.setPadding(new Insets(10));
        buttonArea.setAlignment(Pos.CENTER);

        Button addButton = new Button("添加货物");
        addButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        addButton.setOnAction(e -> listener.onAddCargo());

        Button refreshButton = new Button("刷新");
        refreshButton.setStyle("-fx-background-color: #03A9F4; -fx-text-fill: white;");
        refreshButton.setOnAction(e -> {
            try {
                loadData();
                statusLabel.setText("数据已刷新");
            } catch (IOException ex) {
                statusLabel.setText("刷新失败: " + ex.getMessage());
            }
        });

        buttonArea.getChildren().addAll(addButton, refreshButton);

        return buttonArea;
    }

    private HBox createStatusBar() {
        HBox statusBar = new HBox(10);
        statusBar.setPadding(new Insets(10));
        statusBar.setStyle("-fx-background-color: #e0e0e0;");

        statusLabel = new Label("准备就绪");
        HBox.setHgrow(statusLabel, Priority.ALWAYS);

        statusBar.getChildren().addAll(statusLabel);

        return statusBar;
    }

    private void loadData() throws IOException {
        cargoData.clear();

        File file = new File(CARGO_DATE_FILE);
        if (!file.exists()) {
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 8) {
                    String username = parts[0];
                    String cargoId = parts[1];
                    String name = parts[2];
                    double weight = Double.parseDouble(parts[3]);
                    String destination = parts[4];
                    String flightNumber = parts[5];
                    String departureDate = parts[6];
                    String status = parts[7];

                    if (currentUser.equals("admin") || currentUser.equals(username)) {
                        cargoData.add(new Cargo(username, cargoId, name, weight, destination, flightNumber, departureDate, status));
                    }
                }
            }
        }
    }

    private void handleSearch(String keyword, String status) {
        try {
            loadData(); // 重新加载所有数据

            if (keyword.isEmpty() && status.equals("全部")) {
                return; // 无需过滤
            }

            ObservableList<Cargo> filteredData = FXCollections.observableArrayList();

            for (Cargo cargo : cargoData) {
                boolean matchesKeyword = keyword.isEmpty() ||
                        cargo.getCargoId().contains(keyword) ||
                        cargo.getName().contains(keyword) ||
                        cargo.getDestination().contains(keyword) ||
                        cargo.getUsername().contains(keyword);

                boolean matchesStatus = status.equals("全部") || cargo.getStatus().equals(status);

                if (matchesKeyword && matchesStatus) {
                    filteredData.add(cargo);
                }
            }

            cargoTable.setItems(filteredData);
            statusLabel.setText("搜索结果: " + filteredData.size() + " 条记录");
        } catch (IOException e) {
            statusLabel.setText("搜索失败: " + e.getMessage());
        }
    }

    private void showCargoDetails(Cargo cargo) {
        try (BufferedReader reader = new BufferedReader(new FileReader(ORDERS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 11 && parts[4].equals(cargo.getCargoId())) {
                    Dialog<ButtonType> dialog = new Dialog<>();
                    dialog.setTitle("货物详情");
                    dialog.setHeaderText("货物详细信息");

                    ButtonType closeButtonType = new ButtonType("关闭", ButtonBar.ButtonData.CANCEL_CLOSE);
                    dialog.getDialogPane().getButtonTypes().addAll(closeButtonType);

                    GridPane grid = new GridPane();
                    grid.setHgap(10);
                    grid.setVgap(10);
                    grid.setPadding(new Insets(20, 150, 10, 10));

                    grid.add(new Label("订单ID:"), 0, 0);
                    grid.add(new Label(parts[0]), 1, 0);
                    grid.add(new Label("用户名称:"), 0, 1);
                    grid.add(new Label(parts[1]), 1, 1);
                    grid.add(new Label("运费:"), 0, 2);
                    grid.add(new Label(parts[2]), 1, 2);
                    grid.add(new Label("是否支付:"), 0, 3);
                    grid.add(new Label(parts[3]), 1, 3);
                    grid.add(new Label("货物ID:"), 0, 4);
                    grid.add(new Label(parts[4]), 1, 4);
                    grid.add(new Label("货物名称:"), 0, 5);
                    grid.add(new Label(parts[5]), 1, 5);
                    grid.add(new Label("重量(kg):"), 0, 6);
                    grid.add(new Label(parts[6]), 1, 6);
                    grid.add(new Label("目的地:"), 0, 7);
                    grid.add(new Label(parts[7]), 1, 7);
                    grid.add(new Label("航班号:"), 0, 8);
                    grid.add(new Label(parts[8]), 1, 8);
                    grid.add(new Label("预计起飞时间:"), 0, 9);
                    grid.add(new Label(parts[9]), 1, 9);
                    grid.add(new Label("状态:"), 0, 10);
                    grid.add(new Label(parts[10]), 1, 10);

                    dialog.getDialogPane().setContent(grid);

                    dialog.showAndWait();
                    break;
                }
            }
        } catch (IOException ex) {
            System.err.println("读取订单数据失败: " + ex.getMessage());
        }
    }

    private void editCargoDetails(Cargo cargo) {
        try (BufferedReader reader = new BufferedReader(new FileReader(ORDERS_FILE))) {
            List<String> lines = new ArrayList<>();
            String line;
            int index = -1;

            // 读取所有行并查找匹配的货物记录
            while ((line = reader.readLine()) != null) {
                lines.add(line);
                String[] parts = line.split(",");
                if (parts.length >= 11 && parts[4].equals(cargo.getCargoId())) {
                    index = lines.size() - 1; // 记录当前行索引
                }
            }

            // 检查是否找到了匹配的记录
            if (index != -1) {
                // 获取当前行的字段
                String[] currentParts = lines.get(index).split(",");

                Dialog<ButtonType> dialog = new Dialog<>();
                dialog.setTitle("修改货物信息");
                dialog.setHeaderText("修改收件人信息");

                ButtonType saveButtonType = new ButtonType("保存", ButtonBar.ButtonData.OK_DONE);
                dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

                GridPane grid = new GridPane();
                grid.setHgap(10);
                grid.setVgap(10);
                grid.setPadding(new Insets(20, 150, 10, 10));

                // 使用当前行的第8个字段（索引7）作为收件人初始值
                TextField recipientField = new TextField(currentParts[7]);
                grid.add(new Label("收件人:"), 0, 0);
                grid.add(recipientField, 1, 0);

                dialog.getDialogPane().setContent(grid);

                Optional<ButtonType> result = dialog.showAndWait();
                if (result.isPresent() && result.get() == saveButtonType) {
                    String newRecipient = recipientField.getText();

                    // 更新收件人信息
                    currentParts[7] = newRecipient;
                    lines.set(index, String.join(",", currentParts));

                    try (BufferedWriter writer = new BufferedWriter(new FileWriter(ORDERS_FILE))) {
                        for (String l : lines) {
                            writer.write(l);
                            writer.newLine();
                        }
                        // 刷新表格
                        loadData();
                        cargoTable.refresh();
                        statusLabel.setText("收件人信息已更新");
                    } catch (IOException ex) {
                        statusLabel.setText("保存订单数据失败: " + ex.getMessage());
                    }
                }
            } else {
                // 未找到匹配的记录
                statusLabel.setText("未找到该货物的订单记录");
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("错误");
                alert.setHeaderText("未找到订单记录");
                alert.setContentText("无法找到与所选货物匹配的订单记录。");
                alert.showAndWait();
            }
        } catch (IOException ex) {
            statusLabel.setText("读取订单数据失败: " + ex.getMessage());
        }
    }
}