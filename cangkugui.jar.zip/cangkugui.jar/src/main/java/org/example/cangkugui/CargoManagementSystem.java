package org.example.cangkugui;

import javafx.application.Application;
import javafx.stage.Stage;

import java.io.IOException;

public class CargoManagementSystem extends Application {
    private UserManager userManager;
    private UIController uiController;

    @Override
    public void start(Stage primaryStage) throws IOException {
        // 初始化用户管理器
        userManager = new UserManager();

        // 初始化UI控制器
        uiController = new UIController(primaryStage, userManager);

        // 显示登录页面
        uiController.showLoginPage();
    }

    public static void main(String[] args) {
        launch();
    }
}