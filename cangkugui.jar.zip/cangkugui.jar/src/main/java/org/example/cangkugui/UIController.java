package org.example.cangkugui;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;

public class UIController {
    private static final String USERS_FILE = "src/users.txt";
    private final Stage primaryStage;
    private final UserManager userManager;
    private Scene loginScene;
    private Scene registerScene;
    private Scene mainScene;
    private Label statusLabel;
    private AnchorPane loginPane;
    private AnchorPane registerPane;
    private UserManagementController userManagementController;
    private CargoManagementPanel cargoManagementPanel;
    private String currentUser;
    private Order order;

    // 服务类实例
    private OrderService orderService;
    private PaymentService paymentService;

    public UIController(Stage primaryStage, UserManager userManager) {
        this.primaryStage = primaryStage;
        this.userManager = userManager;
        this.userManagementController = new UserManagementController(primaryStage, userManager, this);

        createLoginPane();
        createRegisterPane();

        // 初始化 CargoManagementPanel
        try {
            this.cargoManagementPanel = new CargoManagementPanel(primaryStage, new CargoManagementPanel.CargoManagementListener() {
                @Override
                public void onBackToMainMenu() {
                    // 实现返回主菜单逻辑
                }

                @Override
                public void onAddCargo() {
                    // 实现添加货物逻辑
                }

                @Override
                public void onEditCargo(CargoManagementPanel.Cargo cargo) {
                    // 实现编辑货物逻辑
                }

                @Override
                public void onDeleteCargo(CargoManagementPanel.Cargo cargo) {
                    // 实现删除货物逻辑
                }

                @Override
                public void onViewDetails(CargoManagementPanel.Cargo cargo) {
                    // 实现查看详情逻辑
                }
            }, "");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // 初始化服务类，传入 cargoManagementPanel 和 UIController
        this.orderService = new OrderService(primaryStage, userManager, statusLabel, cargoManagementPanel);
        this.paymentService = new PaymentService(primaryStage, userManager, statusLabel, this); // 关键修改

        // 初始化场景
        loginScene = new Scene(loginPane, 800, 600);
        registerScene = new Scene(registerPane, 800, 600);
    }
    // 创建登录页面
    private void createLoginPane() {
        loginPane = new AnchorPane();
        loginPane.setStyle("-fx-background-color: #f0f8ff;");

        Text title = new Text("航空货运管理系统");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 28));
        title.setFill(Color.DARKBLUE);
        AnchorPane.setTopAnchor(title, 80.0);
        AnchorPane.setLeftAnchor(title, 300.0);
        // 设置背景图片
        Image backgroundImage = new Image(getClass().getResourceAsStream("/78a746b395c3a653f13f454362acfd8.jpg"));
        ImageView backgroundImageView = new ImageView(backgroundImage);
        backgroundImageView.fitWidthProperty().bind(loginPane.widthProperty());
        backgroundImageView.fitHeightProperty().bind(loginPane.heightProperty());
        loginPane.getChildren().add(backgroundImageView);

        VBox loginBox = new VBox(15);
        loginBox.setPadding(new Insets(20));
        loginBox.setStyle("-fx-background-color: white; -fx-background-radius: 10;");
        loginBox.setOpacity(0.5);
        AnchorPane.setTopAnchor(loginBox, 150.0);
        AnchorPane.setLeftAnchor(loginBox, 250.0);
        AnchorPane.setRightAnchor(loginBox, 250.0);
        HBox buttonBox = new HBox(15);
        buttonBox.setPadding(new Insets(20));
        buttonBox.setOpacity(0.8);

        Label usernameLabel = new Label("用户名:");
        usernameLabel.setFont(Font.font("Arial", 14));
        usernameLabel.setOpacity(0.8);
        TextField usernameField = new TextField();
        usernameField.setPrefHeight(35);
        usernameField.setPromptText("请输入用户名");
        usernameField.setOpacity(0.8);

        Label passwordLabel = new Label("密码:");
        passwordLabel.setFont(Font.font("Arial", 14));
        passwordLabel.setOpacity(0.8);
        PasswordField passwordField = new PasswordField();
        passwordField.setPrefHeight(35);
        passwordField.setPromptText("请输入密码");
        passwordField.setOpacity(0.8);

        Button loginButton = new Button("登录");
        loginButton.setPrefHeight(40);
        loginButton.setStyle("-fx-background-color: #1e90ff; -fx-text-fill: white;");
        loginButton.setPrefWidth(120);
        loginButton.setOpacity(0.8);

        Button adminLoginButton = new Button("管理员登录");
        adminLoginButton.setPrefHeight(40);
        adminLoginButton.setStyle("-fx-background-color: #1e90ff; -fx-text-fill: white;");
        adminLoginButton.setPrefWidth(120);
        adminLoginButton.setOpacity(0.8);

        Button registerButton = new Button("注册新账户");
        registerButton.setPrefHeight(35);
        registerButton.setStyle("-fx-background-color: transparent; -fx-text-fill: #1e90ff; -fx-underline: true;");
        registerButton.setPrefWidth(120);

        statusLabel = new Label("");
        statusLabel.setFont(Font.font("Arial", 12));
        statusLabel.setTextFill(Color.RED);

        buttonBox.getChildren().addAll(loginButton, adminLoginButton);
        loginBox.getChildren().addAll(usernameLabel, usernameField, passwordLabel, passwordField, buttonBox, registerButton, statusLabel);

        loginButton.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();
            if (userManager.validateUser(username, password)) {
                statusLabel.setText("登录成功！");
                statusLabel.setTextFill(Color.GREEN);
                this.currentUser = username;
                showMainApplication(username);
            } else {
                statusLabel.setText("用户名或密码错误！");
                statusLabel.setTextFill(Color.RED);
            }
        });

        adminLoginButton.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();
            if (AdminManager.validateAdmin(username, password)) {
                statusLabel.setText("管理员登录成功！");
                statusLabel.setTextFill(Color.GREEN);
                userManagementController.showUserManagementPage();
            } else {
                statusLabel.setText("管理员用户名或密码错误！");
                statusLabel.setTextFill(Color.RED);
            }
        });

        registerButton.setOnAction(e -> showRegisterPage());

        loginPane.getChildren().addAll(title, loginBox);
    }

    // 创建注册页面
    private void createRegisterPane() {
        registerPane = new AnchorPane();
        registerPane.setStyle("-fx-background-color: #f0f8ff;");

        Text title = new Text("注册新账户");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        title.setFill(Color.DARKBLUE);
        AnchorPane.setTopAnchor(title, 80.0);
        AnchorPane.setLeftAnchor(title, 320.0);

        VBox registerBox = new VBox(15);
        registerBox.setPadding(new Insets(20));
        registerBox.setStyle("-fx-background-color: white; -fx-background-radius: 10;");
        AnchorPane.setTopAnchor(registerBox, 150.0);
        AnchorPane.setLeftAnchor(registerBox, 250.0);
        AnchorPane.setRightAnchor(registerBox, 250.0);

        Label usernameLabel = new Label("用户名:");
        usernameLabel.setFont(Font.font("Arial", 14));
        TextField usernameField = new TextField();
        usernameField.setPrefHeight(35);
        usernameField.setPromptText("请输入用户名");

        Label passwordLabel = new Label("密码:");
        passwordLabel.setFont(Font.font("Arial", 14));
        PasswordField passwordField = new PasswordField();
        passwordField.setPrefHeight(35);
        passwordField.setPromptText("请输入密码");

        Label confirmPasswordLabel = new Label("确认密码:");
        confirmPasswordLabel.setFont(Font.font("Arial", 14));
        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setPrefHeight(35);
        confirmPasswordField.setPromptText("请再次输入密码");

        Button registerButton = new Button("注册");
        registerButton.setPrefHeight(40);
        registerButton.setStyle("-fx-background-color: #1e90ff; -fx-text-fill: white;");
        registerButton.setPrefWidth(120);

        Button backButton = new Button("返回登录");
        backButton.setPrefHeight(35);
        backButton.setStyle("-fx-background-color: transparent; -fx-text-fill: #1e90ff; -fx-underline: true;");
        backButton.setPrefWidth(120);

        Label registerStatusLabel = new Label("");
        registerStatusLabel.setFont(Font.font("Arial", 12));
        registerStatusLabel.setTextFill(Color.RED);

        registerBox.getChildren().addAll(usernameLabel, usernameField, passwordLabel, passwordField,
                confirmPasswordLabel, confirmPasswordField, registerButton, backButton, registerStatusLabel);

        registerButton.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();
            String confirmPassword = confirmPasswordField.getText();
            if (password.equals(confirmPassword)) {
                if (userManager.registerUser(username, password)) {
                    registerStatusLabel.setText("注册成功！请登录。");
                    registerStatusLabel.setTextFill(Color.GREEN);
                    showLoginPage();
                } else {
                    registerStatusLabel.setText("用户名已存在！");
                    registerStatusLabel.setTextFill(Color.RED);
                }
            } else {
                registerStatusLabel.setText("两次输入的密码不一致！");
                registerStatusLabel.setTextFill(Color.RED);
            }
        });

        backButton.setOnAction(e -> showLoginPage());

        registerPane.getChildren().addAll(title, registerBox);
    }

    // 显示登录页面
    public void showLoginPage() {
        primaryStage.setScene(loginScene);
        primaryStage.show();
    }

    // 显示注册页面
    public void showRegisterPage() {
        primaryStage.setScene(registerScene);
        primaryStage.show();
    }

    // 显示主应用界面（包含所有功能按钮）
    public void showMainApplication(String username) {
        AnchorPane mainPane = new AnchorPane();
        mainPane.setStyle("-fx-background-color: #f5f5f5;");

        Text welcomeText = new Text("欢迎使用航空货运管理系统，" + username + "！");
        welcomeText.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        welcomeText.setFill(Color.DARKBLUE);
        AnchorPane.setTopAnchor(welcomeText, 100.0);
        AnchorPane.setLeftAnchor(welcomeText, 250.0);

        // 功能按钮区域
        VBox buttonBox = new VBox(20);
        buttonBox.setPadding(new Insets(50));
        buttonBox.setStyle("-fx-background-color: white; -fx-background-radius: 10; -fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.2), 10, 0.5, 0, 0);");
        AnchorPane.setTopAnchor(buttonBox, 180.0);
        AnchorPane.setLeftAnchor(buttonBox, 300.0);

        Button placeOrderButton = new Button("下订单");
        placeOrderButton.setPrefHeight(45);
        placeOrderButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-size: 14px;");
        placeOrderButton.setPrefWidth(200);

        Button modifyOrderButton = new Button("修改订单");
        modifyOrderButton.setPrefHeight(45);
        modifyOrderButton.setStyle("-fx-background-color: #FF9800; -fx-text-fill: white; -fx-font-size: 14px;");
        modifyOrderButton.setPrefWidth(200);

        Button payOrderButton = new Button("支付订单");
        payOrderButton.setPrefHeight(45);
        payOrderButton.setStyle("-fx-background-color: #FE1EEE; -fx-text-fill: white; -fx-font-size: 14px;");
        payOrderButton.setPrefWidth(200);

        Button cargoManagementButton = new Button("货物管理");
        cargoManagementButton.setPrefHeight(45);
        cargoManagementButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white; -fx-font-size: 14px;");
        cargoManagementButton.setPrefWidth(200);

        Button logoutButton = new Button("退出登录");
        logoutButton.setPrefHeight(45);
        logoutButton.setStyle("-fx-background-color: #F44336; -fx-text-fill: white; -fx-font-size: 14px;");
        logoutButton.setPrefWidth(200);

        statusLabel = new Label("");
        statusLabel.setFont(Font.font("Arial", 12));
        statusLabel.setTextFill(Color.RED);
        AnchorPane.setTopAnchor(statusLabel, 450.0);
        AnchorPane.setLeftAnchor(statusLabel, 300.0);

        // 按钮事件处理
        placeOrderButton.setOnAction(e -> orderService.showPlaceOrderPage(username));
        modifyOrderButton.setOnAction(e -> orderService.showModifyOrderPage(username));
        payOrderButton.setOnAction(actionEvent ->paymentService.showPaymentListPage(username) );
        cargoManagementButton.setOnAction(e -> {
            try {
                cargoManagementPanel = new CargoManagementPanel(primaryStage, new CargoManagementPanel.CargoManagementListener() {
                    @Override
                    public void onBackToMainMenu() {
                        showMainApplication(username);
                    }

                    @Override
                    public void onAddCargo() {
                        statusLabel.setText("添加货物功能已触发");
                    }

                    @Override
                    public void onEditCargo(CargoManagementPanel.Cargo cargo) {
                        statusLabel.setText("编辑货物: " + cargo.getCargoId());
                    }

                    @Override
                    public void onDeleteCargo(CargoManagementPanel.Cargo cargo) {
                        statusLabel.setText("删除货物: " + cargo.getCargoId());
                    }

                    @Override
                    public void onViewDetails(CargoManagementPanel.Cargo cargo) {
                        statusLabel.setText("查看货物详情: " + cargo.getCargoId());
                    }
                }, username);
                cargoManagementPanel.show();
            } catch (IOException ex) {
                statusLabel.setText("加载货物管理面板失败: " + ex.getMessage());
                statusLabel.setTextFill(Color.RED);
            }
        });

        logoutButton.setOnAction(e -> showLoginPage());

        buttonBox.getChildren().addAll(placeOrderButton, modifyOrderButton, payOrderButton,cargoManagementButton, logoutButton);
        mainPane.getChildren().addAll(welcomeText, buttonBox, statusLabel);

        mainScene = new Scene(mainPane, 800, 600);
        primaryStage.setScene(mainScene);
        primaryStage.show();
    }
}