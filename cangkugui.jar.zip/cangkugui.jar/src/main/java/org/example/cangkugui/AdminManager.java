package org.example.cangkugui;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public class AdminManager {
    private static final String ADMINS_FILE = "src/admin.txt";
    private static final Map<String, String> admins = new HashMap<>();

    static {
        loadAdmins();
    }

    // 加载管理员数据
    private static void loadAdmins() {
        File file = new File(ADMINS_FILE);
        if (!file.exists()) {
            try {
                // 创建默认管理员账户
                registerAdmin("admin", "admin123");
            } catch (Exception e) {
                System.err.println("无法创建默认管理员: " + e.getMessage());
            }
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(":");
                if (parts.length == 2) {
                    admins.put(parts[0], parts[1]);
                }
            }
        } catch (IOException e) {
            System.err.println("加载管理员数据失败: " + e.getMessage());
        }
    }

    // 注册新管理员
    public static boolean registerAdmin(String username, String password) {
        if (admins.containsKey(username)) {
            return false;
        }

        String hashedPassword = hashPassword(password);
        admins.put(username, hashedPassword);

        // 保存到文件
        saveAdmins();
        return true;
    }

    // 密码哈希函数
    private static String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(password.getBytes(StandardCharsets.UTF_8));

            StringBuilder hexString = new StringBuilder();
            for (byte hashByte : hashBytes) {
                String hex = Integer.toHexString(0xff & hashByte);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }

            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            System.err.println("哈希算法不可用: " + e.getMessage());
            return password;
        }
    }

    // 验证管理员
    public static boolean validateAdmin(String username, String password) {
        if (!admins.containsKey(username)) {
            return false;
        }

        String storedHash = admins.get(username);
        String inputHash = hashPassword(password);

        return storedHash.equals(inputHash);
    }

    // 保存管理员数据到文件
    private static void saveAdmins() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ADMINS_FILE))) {
            for (Map.Entry<String, String> entry : admins.entrySet()) {
                writer.write(entry.getKey() + ":" + entry.getValue());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("保存管理员数据失败: " + e.getMessage());
        }
    }
}