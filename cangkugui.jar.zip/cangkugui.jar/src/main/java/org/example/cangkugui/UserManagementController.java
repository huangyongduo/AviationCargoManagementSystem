package org.example.cangkugui;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class UserManagementController {
    private final Stage primaryStage;
    private final UserManager userManager;
    private Scene userManagementScene;
    private TableView<UserData> userTable;
    private ObservableList<UserData> userDataList;
    private Label statusLabel;
    private UIController uiController;

    // 用户数据模型类
    public static class UserData {
        private final String username;
        private final String password;

        public UserData(String username, String password) {
            this.username = username;
            this.password = password;
        }

        public String getUsername() {
            return username;
        }

        public String getPassword() {
            return password;
        }
    }

    public UserManagementController(Stage primaryStage, UserManager userManager,UIController uiController) {
        this.primaryStage = primaryStage;
        this.userManager = userManager;
        this.uiController = uiController;
        userDataList = FXCollections.observableArrayList();
        createUserManagementPane();
    }

    // 创建用户管理界面
    private void createUserManagementPane() {
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #f5f5f5;");

        // 标题
        Text title = new Text("用户管理系统");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        title.setFill(Color.DARKBLUE);

        HBox titleBox = new HBox(title);
        titleBox.setPadding(new Insets(20));
        titleBox.setAlignment(javafx.geometry.Pos.CENTER);
        root.setTop(titleBox);

        // 创建表格
        userTable = new TableView<>();
        userTable.setItems(userDataList);

        TableColumn<UserData, String> usernameCol = new TableColumn<>("用户名");
        usernameCol.setCellValueFactory(new PropertyValueFactory<>("username"));
        usernameCol.setPrefWidth(200);

        TableColumn<UserData, String> passwordCol = new TableColumn<>("密码");
        passwordCol.setCellValueFactory(new PropertyValueFactory<>("password"));
        passwordCol.setPrefWidth(200);

        userTable.getColumns().addAll(usernameCol, passwordCol);

        ScrollPane scrollPane = new ScrollPane(userTable);
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(true);
        root.setCenter(scrollPane);

        // 底部按钮区域
        HBox buttonBox = new HBox(10);
        buttonBox.setPadding(new Insets(15));
        buttonBox.setAlignment(javafx.geometry.Pos.CENTER);

        Button addButton = new Button("添加用户");
        Button editButton = new Button("修改用户");
        Button deleteButton = new Button("删除用户");
        Button refreshButton = new Button("刷新数据");
        Button backButton = new Button("返回登录");

        addButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        editButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white;");
        deleteButton.setStyle("-fx-background-color: #F44336; -fx-text-fill: white;");
        refreshButton.setStyle("-fx-background-color: #FFC107; -fx-text-fill: black;");
        backButton.setStyle("-fx-background-color: #607D8B; -fx-text-fill: white;");

        buttonBox.getChildren().addAll(addButton, editButton, deleteButton, refreshButton, backButton);

        // 状态标签
        statusLabel = new Label("");
        statusLabel.setFont(Font.font("Arial", 12));
        statusLabel.setTextFill(Color.RED);
        statusLabel.setPadding(new Insets(5));
        root.setBottom(VBoxBuilder.create()
                .children(buttonBox, statusLabel)
                .padding(new Insets(15))
                .alignment(javafx.geometry.Pos.CENTER)
                .build());

        // 按钮事件处理
        addButton.setOnAction(e -> showAddUserDialog());
        editButton.setOnAction(e -> showEditUserDialog());
        deleteButton.setOnAction(e -> deleteSelectedUser());
        refreshButton.setOnAction(e -> loadUserData());
        backButton.setOnAction(e -> uiController.showLoginPage());

        // 加载用户数据
        loadUserData();

        userManagementScene = new Scene(root, 800, 600);
    }

    // 显示用户管理页面
    public void showUserManagementPage() {
        loadUserData();
        primaryStage.setTitle("用户管理系统");
        primaryStage.setScene(userManagementScene);
        primaryStage.show();
    }

    // 加载用户数据
    private void loadUserData() {
        userDataList.clear();

        // 从文件加载用户数据
        File file = new File("src/users.txt");
        if (file.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(":");
                    if (parts.length == 2) {
                        userDataList.add(new UserData(parts[0], parts[1]));
                    }
                }
                statusLabel.setText("成功加载 " + userDataList.size() + " 个用户");
                statusLabel.setTextFill(Color.GREEN);
            } catch (IOException e) {
                statusLabel.setText("加载用户数据失败: " + e.getMessage());
                statusLabel.setTextFill(Color.RED);
            }
        } else {
            statusLabel.setText("用户数据文件不存在");
            statusLabel.setTextFill(Color.RED);
        }
    }

    // 显示添加用户对话框
    private void showAddUserDialog() {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("添加新用户");
        dialog.setHeaderText("请输入用户信息");

        // 设置对话框按钮
        ButtonType addButtonType = new ButtonType("添加", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(addButtonType, ButtonType.CANCEL);

        // 创建输入表单
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField usernameField = new TextField();
        usernameField.setPromptText("用户名");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("密码");

        grid.add(new Label("用户名:"), 0, 0);
        grid.add(usernameField, 1, 0);
        grid.add(new Label("密码:"), 0, 1);
        grid.add(passwordField, 1, 1);

        dialog.getDialogPane().setContent(grid);

        // 禁用添加按钮直到输入有效
        Button addButton = (Button) dialog.getDialogPane().lookupButton(addButtonType);
        addButton.setDisable(true);

        // 监听输入字段变化
        usernameField.textProperty().addListener((observable, oldValue, newValue) -> {
            addButton.setDisable(newValue.trim().isEmpty() || passwordField.getText().trim().isEmpty());
        });

        passwordField.textProperty().addListener((observable, oldValue, newValue) -> {
            addButton.setDisable(newValue.trim().isEmpty() || usernameField.getText().trim().isEmpty());
        });

        // 处理对话框结果
        dialog.setResultConverter(dialogButton -> {
            return dialogButton;
        });

        // 显示对话框并处理结果
        Optional<ButtonType> result = dialog.showAndWait();
        result.ifPresent(buttonType -> {
            if (buttonType == addButtonType) {
                String username = usernameField.getText();
                String password = passwordField.getText();

                if (userManager.registerUser(username, password)) {
                    statusLabel.setText("用户 " + username + " 添加成功");
                    statusLabel.setTextFill(Color.GREEN);
                    loadUserData();
                } else {
                    statusLabel.setText("用户 " + username + " 已存在");
                    statusLabel.setTextFill(Color.RED);
                }
            }
        });
    }

    // 显示编辑用户对话框
    private void showEditUserDialog() {
        UserData selectedUser = userTable.getSelectionModel().getSelectedItem();
        if (selectedUser == null) {
            statusLabel.setText("请先选择一个用户");
            statusLabel.setTextFill(Color.RED);
            return;
        }

        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("修改用户");
        dialog.setHeaderText("修改用户: " + selectedUser.getUsername());

        // 设置对话框按钮
        ButtonType saveButtonType = new ButtonType("保存", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        // 创建输入表单
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField usernameField = new TextField(selectedUser.getUsername());
        usernameField.setDisable(true); // 用户名不可修改
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("新密码");

        grid.add(new Label("用户名:"), 0, 0);
        grid.add(usernameField, 1, 0);
        grid.add(new Label("新密码:"), 0, 1);
        grid.add(passwordField, 1, 1);

        dialog.getDialogPane().setContent(grid);

        // 禁用保存按钮直到输入有效
        Button saveButton = (Button) dialog.getDialogPane().lookupButton(saveButtonType);
        saveButton.setDisable(true);

        // 监听输入字段变化
        passwordField.textProperty().addListener((observable, oldValue, newValue) -> {
            saveButton.setDisable(newValue.trim().isEmpty());
        });

        // 处理对话框结果
        dialog.setResultConverter(dialogButton -> {
            return dialogButton;
        });

        // 显示对话框并处理结果
        Optional<ButtonType> result = dialog.showAndWait();
        result.ifPresent(buttonType -> {
            if (buttonType == saveButtonType) {
                String username = usernameField.getText();
                String newPassword = passwordField.getText();

                if (updateUserPassword(username, newPassword)) {
                    statusLabel.setText("用户 " + username + " 密码已更新");
                    statusLabel.setTextFill(Color.GREEN);
                    loadUserData();
                } else {
                    statusLabel.setText("更新用户 " + username + " 失败");
                    statusLabel.setTextFill(Color.RED);
                }
            }
        });
    }

    // 更新用户密码
    private boolean updateUserPassword(String username, String newPassword) {
        // 读取所有用户
        File file = new File("src/users.txt");
        List<String> lines = new ArrayList<>();
        boolean userFound = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(":");
                if (parts.length == 2 && parts[0].equals(username)) {
                    userFound = true;
                    // 更新密码（重新哈希）
                    String hashedPassword = hashPassword(newPassword);
                    lines.add(username + ":" + hashedPassword);
                } else {
                    lines.add(line);
                }
            }
        } catch (IOException e) {
            statusLabel.setText("读取用户数据失败: " + e.getMessage());
            statusLabel.setTextFill(Color.RED);
            return false;
        }

        if (!userFound) {
            return false;
        }

        // 写回文件
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
            return true;
        } catch (IOException e) {
            statusLabel.setText("写入用户数据失败: " + e.getMessage());
            statusLabel.setTextFill(Color.RED);
            return false;
        }
    }

    // 密码哈希函数
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(password.getBytes(StandardCharsets.UTF_8));

            StringBuilder hexString = new StringBuilder();
            for (byte hashByte : hashBytes) {
                String hex = Integer.toHexString(0xff & hashByte);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }

            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            System.err.println("哈希算法不可用: " + e.getMessage());
            return password;
        }
    }

    // 删除选中的用户
    private void deleteSelectedUser() {
        UserData selectedUser = userTable.getSelectionModel().getSelectedItem();
        if (selectedUser == null) {
            statusLabel.setText("请先选择一个用户");
            statusLabel.setTextFill(Color.RED);
            return;
        }

        // 确认对话框
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("确认删除");
        alert.setHeaderText("删除用户");
        alert.setContentText("确定要删除用户 " + selectedUser.getUsername() + " 吗?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            if (deleteUser(selectedUser.getUsername())) {
                statusLabel.setText("用户 " + selectedUser.getUsername() + " 已删除");
                statusLabel.setTextFill(Color.GREEN);
                loadUserData();
            } else {
                statusLabel.setText("删除用户失败");
                statusLabel.setTextFill(Color.RED);
            }
        }
    }

    // 删除用户
    private boolean deleteUser(String username) {
        // 读取所有用户
        File file = new File("src/users.txt");
        List<String> lines = new ArrayList<>();
        boolean userFound = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(":");
                if (parts.length == 2 && parts[0].equals(username)) {
                    userFound = true;
                    // 跳过要删除的用户
                    continue;
                }
                lines.add(line);
            }
        } catch (IOException e) {
            statusLabel.setText("读取用户数据失败: " + e.getMessage());
            statusLabel.setTextFill(Color.RED);
            return false;
        }

        if (!userFound) {
            return false;
        }

        // 写回文件
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
            return true;
        } catch (IOException e) {
            statusLabel.setText("写入用户数据失败: " + e.getMessage());
            statusLabel.setTextFill(Color.RED);
            return false;
        }
    }


    // 辅助类用于创建VBox
    private static class VBoxBuilder {
        private final VBox vbox = new VBox();

        public static VBoxBuilder create() {
            return new VBoxBuilder();
        }

        public VBoxBuilder children(Node... nodes) {
            vbox.getChildren().addAll(nodes);
            return this;
        }

        public VBoxBuilder padding(Insets insets) {
            vbox.setPadding(insets);
            return this;
        }

        public VBoxBuilder alignment(javafx.geometry.Pos pos) {
            vbox.setAlignment(pos);
            return this;
        }

        public VBox build() {
            return vbox;
        }
    }
}