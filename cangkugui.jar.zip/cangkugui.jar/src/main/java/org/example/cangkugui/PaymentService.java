package org.example.cangkugui;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class PaymentService {
    private final Stage primaryStage;
    private final UserManager userManager;
    private Label statusLabel;
    private final UIController uiController; // 新增：持有 UIController 引用

    // 修改构造方法，传入 UIController
    public PaymentService(Stage primaryStage, UserManager userManager, Label statusLabel, UIController uiController) {
        this.primaryStage = primaryStage;
        this.userManager = userManager;
        this.statusLabel = statusLabel;
        this.uiController = uiController;
    }

    // 显示支付订单列表页面
    public void showPaymentListPage(String username) {
        ObservableList<Order> unpaidOrders = FXCollections.observableArrayList();
        try (BufferedReader reader = new BufferedReader(new FileReader("src/orders.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[1].equals(username) && !Boolean.parseBoolean(parts[3])) {
                    String orderId = parts[0];
                    Order order = new Order(orderId, username);
                    order.setFreight(Double.parseDouble(parts[2]));
                    order.setPaid(Boolean.parseBoolean(parts[3]));
                    for (int i = 4; i < parts.length; i += 7) {
                        if (i + 6 < parts.length) { // 检查索引是否越界
                            String cargoId = parts[i];
                            String name = parts[i + 1];
                            double weight = Double.parseDouble(parts[i + 2]);
                            String destination = parts[i + 3];
                            String flightNumber = parts[i + 4];
                            String departureDate = parts[i + 5];
                            String status = parts[i + 6];
                            CargoManagementPanel.Cargo cargo = new CargoManagementPanel.Cargo(
                                    username, cargoId, name, weight, destination, flightNumber, departureDate, status);
                            order.addCargo(cargo);
                        } else {
                            // 处理不完整的货物信息
                            System.err.println("订单 " + orderId + " 的货物信息不完整，跳过部分货物。");
                            break;
                        }
                    }
                    unpaidOrders.add(order);
                }
            }
        } catch (IOException e) {
            System.err.println("加载未支付订单失败: " + e.getMessage());
            showErrorAlert("加载订单失败", e.getMessage());
        }

        TableView<Order> orderTable = new TableView<>();
        orderTable.setItems(unpaidOrders);

        TableColumn<Order, String> orderIdCol = new TableColumn<>("订单 ID");
        orderIdCol.setCellValueFactory(param -> new ReadOnlyStringWrapper(param.getValue().getOrderId()));
        orderIdCol.setPrefWidth(120);

        TableColumn<Order, String> userCol = new TableColumn<>("用户名称");
        userCol.setCellValueFactory(param -> new ReadOnlyStringWrapper(param.getValue().getUser()));
        userCol.setPrefWidth(150);

        TableColumn<Order, Double> freightCol = new TableColumn<>("运费");
        freightCol.setCellValueFactory(param -> new ReadOnlyObjectWrapper<>(param.getValue().getFreight()));
        freightCol.setPrefWidth(100);

        TableColumn<Order, Void> actionCol = new TableColumn<>("操作");
        actionCol.setPrefWidth(100);
        actionCol.setCellFactory(param -> new TableCell<>() {
            private final Button payButton = new Button("支付");

            {
                payButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
                payButton.setOnAction(event -> {
                    Order order = getTableView().getItems().get(getIndex());
                    showPaymentPage(order);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(payButton);
                }
            }
        });

        // 添加支付订单按钮
        TableColumn<Order, Void> payAllCol = new TableColumn<>("支付订单");
        payAllCol.setPrefWidth(120);
        payAllCol.setCellFactory(param -> new TableCell<>() {
            private final Button payAllButton = new Button("支付订单");

            {
                payAllButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white;");
                payAllButton.setOnAction(event -> {
                    Order order = getTableView().getItems().get(getIndex());
                    showPaymentPage(order);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(payAllButton);
                }
            }
        });

        // 添加修改订单按钮
        TableColumn<Order, Void> editCol = new TableColumn<>("修改订单");
        editCol.setPrefWidth(120);
        editCol.setCellFactory(param -> new TableCell<>() {
            private final Button editButton = new Button("修改订单");

            {
                editButton.setStyle("-fx-background-color: #FFC107; -fx-text-fill: black;");
                editButton.setOnAction(event -> {
                    Order order = getTableView().getItems().get(getIndex());
                    showEditOrderDialog(order);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(editButton);
                }
            }
        });

        // 添加查看订单详情按钮
        TableColumn<Order, Void> viewCol = new TableColumn<>("查看详情");
        viewCol.setPrefWidth(120);
        viewCol.setCellFactory(param -> new TableCell<>() {
            private final Button viewButton = new Button("查看详情");

            {
                viewButton.setStyle("-fx-background-color: #9C27B0; -fx-text-fill: white;");
                viewButton.setOnAction(event -> {
                    Order order = getTableView().getItems().get(getIndex());
                    showOrderDetails(order);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(viewButton);
                }
            }
        });

        orderTable.getColumns().addAll(orderIdCol, userCol, freightCol, actionCol, payAllCol, editCol, viewCol);

        // 添加返回和刷新按钮（修复 uiController 引用）
        Button backButton = new Button("返回");
        backButton.setOnAction(e -> uiController.showMainApplication(username));

        Button refreshButton = new Button("刷新");
        refreshButton.setOnAction(e -> showPaymentListPage(username));

        HBox buttonBox = new HBox(10);
        buttonBox.getChildren().addAll(backButton, refreshButton);

        VBox vbox = new VBox(10);
        vbox.getChildren().addAll(new Label("待支付订单列表"), orderTable, buttonBox);

        Scene orderListScene = new Scene(vbox, 900, 600);
        primaryStage.setTitle("待支付订单 - " + username);
        primaryStage.setScene(orderListScene);
        primaryStage.show();
    }

    // 显示支付页面
    private void showPaymentPage(Order order) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("支付订单");
        dialog.setHeaderText("请选择支付方式并确认支付");

        ButtonType payButtonType = new ButtonType("支付", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(payButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        ComboBox<String> paymentMethodComboBox = new ComboBox<>();
        paymentMethodComboBox.getItems().addAll("支付宝", "微信支付", "银行卡支付");
        paymentMethodComboBox.setValue("支付宝");

        grid.add(new Label("支付方式:"), 0, 0);
        grid.add(paymentMethodComboBox, 1, 0);

        grid.add(new Label("订单 ID:"), 0, 1);
        grid.add(new Label(order.getOrderId()), 1, 1);

        grid.add(new Label("运费:"), 0, 2);
        grid.add(new Label(String.format("%.2f", order.getFreight())), 1, 2);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            return dialogButton;
        });

        // 显示对话框并处理结果
        Optional<ButtonType> result = dialog.showAndWait();
        result.ifPresent(buttonType -> {
            if (buttonType == payButtonType) {
                // 处理支付逻辑
                order.setPaid(true);
                saveOrder(order);
                statusLabel.setText("订单 " + order.getOrderId() + " 已支付");
                statusLabel.setTextFill(Color.GREEN);
                showPaymentListPage(order.getUser());
            }
        });
    }

    // 显示订单详情
    private void showOrderDetails(Order order) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("订单详情");
        dialog.setHeaderText("订单 " + order.getOrderId() + " 详情");

        ButtonType closeButtonType = new ButtonType("关闭", ButtonBar.ButtonData.CANCEL_CLOSE);
        dialog.getDialogPane().getButtonTypes().addAll(closeButtonType);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        grid.add(new Label("订单 ID:"), 0, 0);
        grid.add(new Label(order.getOrderId()), 1, 0);

        grid.add(new Label("发件人:"), 0, 1);
        grid.add(new Label(order.getSender()), 1, 1);

        grid.add(new Label("收件人:"), 0, 2);
        grid.add(new Label(order.getRecipient()), 1, 2);

        grid.add(new Label("运费:"), 0, 3);
        grid.add(new Label(String.format("%.2f", order.getFreight())), 1, 3);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            return dialogButton;
        });

        dialog.showAndWait();
    }

    // 显示修改订单对话框
    private void showEditOrderDialog(Order order) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("修改订单");
        dialog.setHeaderText("修改订单 " + order.getOrderId() + " 信息");

        ButtonType saveButtonType = new ButtonType("保存", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField senderField = new TextField(order.getSender());
        TextField recipientField = new TextField(order.getRecipient());

        grid.add(new Label("发件人:"), 0, 0);
        grid.add(senderField, 1, 0);

        grid.add(new Label("收件人:"), 0, 1);
        grid.add(recipientField, 1, 1);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            return dialogButton;
        });

        // 显示对话框并处理结果
        Optional<ButtonType> result = dialog.showAndWait();
        result.ifPresent(buttonType -> {
            if (buttonType == saveButtonType) {
                String newSender = senderField.getText();
                String newRecipient = recipientField.getText();

                order.setSender(newSender);
                order.setRecipient(newRecipient);

                saveOrder(order);
                statusLabel.setText("订单 " + order.getOrderId() + " 信息已更新");
                statusLabel.setTextFill(Color.GREEN);
                showPaymentListPage(order.getUser());
            }
        });
    }

    // 保存订单信息
    private void saveOrder(Order order) {
        List<String> allOrders = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("src/orders.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[0].equals(order.getOrderId())) {
                    StringBuilder newLine = new StringBuilder();
                    newLine.append(order.getOrderId()).append(",");
                    newLine.append(order.getUser()).append(",");
                    newLine.append(order.getFreight()).append(",");
                    newLine.append(order.isPaid()).append(",");
                    for (CargoManagementPanel.Cargo cargo : order.getCargoList()) {
                        newLine.append(cargo.getCargoId()).append(",");
                        newLine.append(cargo.getName()).append(",");
                        newLine.append(cargo.getWeight()).append(",");
                        newLine.append(cargo.getDestination()).append(",");
                        newLine.append(cargo.getFlightNumber()).append(",");
                        newLine.append(cargo.getDepartureDate()).append(",");
                        newLine.append(cargo.getStatus()).append(",");
                    }
                    if (newLine.length() > 0) {
                        newLine.deleteCharAt(newLine.length() - 1); // 删除最后一个逗号
                    }
                    allOrders.add(newLine.toString());
                } else {
                    allOrders.add(line);
                }
            }
        } catch (IOException e) {
            System.err.println("读取订单数据失败: " + e.getMessage());
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("src/orders.txt"))) {
            for (String line : allOrders) {
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("保存订单数据失败: " + e.getMessage());
        }
    }

    // 显示错误提示框
    private void showErrorAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}