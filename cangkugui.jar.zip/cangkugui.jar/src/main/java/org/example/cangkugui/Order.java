package org.example.cangkugui;

import java.util.ArrayList;
import java.util.List;

// 订单类
public class Order {
    private String orderId;
    private String user;
    private List<CargoManagementPanel.Cargo> cargoList;
    private double freight;
    private boolean isPaid;
    private String sender;
    private String recipient;

    // 主构造函数
    public Order(String orderId, String user, String sender, String recipient) {
        this.orderId = orderId;
        this.user = user;
        this.cargoList = new ArrayList<>(); // 初始化！
        this.freight = 0.0;
        this.isPaid = false;
        this.sender = sender;
        this.recipient = recipient;
    }

    // 如果有其他构造函数，也需要初始化 cargoList
    public Order(String orderId, String user) {
        this.orderId = orderId;
        this.user = user;
        this.cargoList = new ArrayList<>(); // 初始化！
        this.freight = 0.0;
        this.isPaid = false;
    }

    public String getOrderId() {
        return orderId;
    }

    public String getUser() {
        return user;
    }

    public List<CargoManagementPanel.Cargo> getCargoList() {
        return cargoList;
    }

    public void addCargo(CargoManagementPanel.Cargo cargo) {
        cargoList.add(cargo);
    }

    public double getFreight() {
        return freight;
    }

    public void setFreight(double freight) {
        this.freight = freight;
    }

    public boolean isPaid() {
        return isPaid;
    }

    public void setPaid(boolean paid) {
        isPaid = paid;
    }

    public String getSender() {
        return sender;
    }

    public String getRecipient() {
        return recipient;
    }

    // 设置发件人
    public void setSender(String sender) {
        this.sender = sender;
    }



    // 设置收件人
    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }
}

// 支付类
class Payment {
    private String paymentMethod;
    private double amount;

    public Payment(String paymentMethod, double amount) {
        this.paymentMethod = paymentMethod;
        this.amount = amount;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public double getAmount() {
        return amount;
    }
}