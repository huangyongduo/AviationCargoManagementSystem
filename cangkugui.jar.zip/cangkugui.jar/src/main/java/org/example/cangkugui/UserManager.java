package org.example.cangkugui;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public class UserManager {
    private static final String USERS_FILE = "src/users.txt";
    private final Map<String, String> users = new HashMap<>();
    private static final String ADMIN_FILE = "src/admin.txt";
    private final Map<String, String> admins = new HashMap<>();

    public UserManager() {
        loadUsers();
    }




    // 加载用户数据
    private void loadUsers() {
        File file = new File(USERS_FILE);
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(":");
                if (parts.length == 2) {
                    users.put(parts[0], parts[1]);
                }
            }
        } catch (IOException e) {
            System.err.println("加载用户数据失败: " + e.getMessage());
        }
    }

    // 注册新用户
    public boolean registerUser(String username, String password) {
        if (users.containsKey(username)) {
            return false;
        }

        String hashedPassword = hashPassword(password);
        users.put(username, hashedPassword);

        // 保存到文件
        saveUsers();
        return true;
    }

    // 密码哈希函数
    public static String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(password.getBytes(StandardCharsets.UTF_8));

            StringBuilder hexString = new StringBuilder();
            for (byte hashByte : hashBytes) {
                String hex = Integer.toHexString(0xff & hashByte);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }

            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            System.err.println("哈希算法不可用: " + e.getMessage());
            return password;
        }
    }

    // 验证用户
    public boolean validateUser(String username, String password) {
        if (!users.containsKey(username)) {
            return false;
        }

        String storedHash = users.get(username);
        String inputHash = hashPassword(password);

        return storedHash.equals(inputHash);
    }

    // 保存用户数据到文件
    private void saveUsers() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(USERS_FILE))) {
            for (Map.Entry<String, String> entry : users.entrySet()) {
                writer.write(entry.getKey() + ":" + entry.getValue());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("保存用户数据失败: " + e.getMessage());
        }
    }
}