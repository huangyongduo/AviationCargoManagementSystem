package org.example.cangkugui;

public class Main {
    public static void main(String[] args) {
        CargoManagementSystem.main(args);
    }
}
